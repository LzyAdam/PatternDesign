package edu.neu.csye7374;

class SumCommand implements Command {
    private Calculator calculator;
    private int[] numbers;

    public SumCommand(Calculator calculator, int[] numbers) {
        this.calculator = calculator;
        this.numbers = numbers;
    }

    @Override
    public void execute() {
        calculator.sum(numbers);
    }
}