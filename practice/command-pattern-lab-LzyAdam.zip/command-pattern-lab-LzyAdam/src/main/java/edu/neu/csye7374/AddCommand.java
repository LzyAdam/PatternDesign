package edu.neu.csye7374;

public class AddCommand implements Command{
    private Calculator calculator;
    private int operand1, operand2;

    public AddCommand(Calculator calculator, int operand1, int operand2) {
        this.calculator = calculator;
        this.operand1 = operand1;
        this.operand2 = operand2;
    }
    @Override
    public void execute() {
        calculator.add(operand1, operand2);
    }
}
