package edu.neu.csye7374;

class DivideCommand implements Command {
    private Calculator calculator;
    private int operand1, operand2;

    public DivideCommand(Calculator calculator, int operand1, int operand2) {
        this.calculator = calculator;
        this.operand1 = operand1;
        this.operand2 = operand2;
    }

    @Override
    public void execute() {
        calculator.divide(operand1, operand2);
    }
}