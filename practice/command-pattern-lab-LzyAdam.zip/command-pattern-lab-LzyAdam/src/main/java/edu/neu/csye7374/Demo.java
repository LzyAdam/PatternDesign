package edu.neu.csye7374;

import java.util.*;

public class Demo {
    public static void demo(){
        System.out.println("demo......");
        Calculator calculator = new Calculator();
        List<Command> batchJobs = new ArrayList<>();

        // Setting up batch jobs
        batchJobs.add(new AddCommand(calculator, 6, 3));
        batchJobs.add(new SubtractCommand(calculator, 6, 3));
        batchJobs.add(new MultiplyCommand(calculator, 6, 3));
        batchJobs.add(new DivideCommand(calculator, 6, 3));
        batchJobs.add(new SumCommand(calculator, new int[]{1, 2, 3, 4}));

        // Executing batch jobs
        for (Command job : batchJobs) {
            job.execute();
        }
    }

}
