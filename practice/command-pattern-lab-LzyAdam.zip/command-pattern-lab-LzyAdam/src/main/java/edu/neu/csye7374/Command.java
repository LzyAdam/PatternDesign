package edu.neu.csye7374;

interface Command {
    void execute();
}