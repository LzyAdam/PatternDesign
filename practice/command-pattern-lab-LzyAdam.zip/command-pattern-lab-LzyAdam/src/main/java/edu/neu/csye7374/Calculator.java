package edu.neu.csye7374;

class Calculator {
    private int result;

    public void add(int a, int b) {
        result = a + b;
        System.out.println("Addition Result: " + result);
    }

    public void subtract(int a, int b) {
        result = a - b;
        System.out.println("Subtraction Result: " + result);
    }

    public void multiply(int a, int b) {
        result = a * b;
        System.out.println("Multiplication Result: " + result);
    }

    public void divide(int a, int b) {
        if (b != 0) {
            result = a / b;
            System.out.println("Division Result: " + result);
        } else {
            System.out.println("Cannot divide by zero.");
        }
    }

    public void sum(int[] numbers) {
        result = 0;
        for (int num : numbers) {
            result += num;
        }
        System.out.println("Sum Result: " + result);
    }
}

